// Affinity PS Vita runtime — shared data contract.
// Mirrors psp_runtime/include/affinity_psp.h but WITHOUT the PSP GU dependency:
// the Vita renders with vitaGL (fixed-function GL), so vertices go through GL
// vertex arrays instead of sceGumDrawArray, and there are no GU_* flag macros.
// The struct layouts are identical to the PSP ones so the generated scene data
// (psv_mapdata.h, a copy of psp_mapdata.h) drops in unchanged.
#pragma once

// One interleaved scene vertex. color is 0xAABBGGRR (== GL RGBA byte order in
// little-endian memory, so glColorPointer(4, GL_UNSIGNED_BYTE, ...) reads it).
typedef struct {
    float        u, v;     // texcoord
    unsigned int color;    // 0xAABBGGRR
    float        x, y, z;  // position
} AfnVertex;

// Rig vertex: carries a normal for lighting (camera headlamp).
typedef struct {
    float        u, v;
    unsigned int color;
    float        nx, ny, nz;
    float        x, y, z;
} AfnRigVertex;

// A skinnable rig asset (player or NPC). The scene can carry several distinct
// rigs (psv_rig.h emits one per used model). All geometry is raw model space;
// the runtime CPU-skins (skinned = animPose[bone]·baseVert) per instance.
typedef struct {
    int   bones, verts, mats, clips, cull;   // counts + cull mode (0 back/1 front/2 none)
    float scale;                             // model -> world base scale
    int   camlight;                          // 1 = headlamp follows the camera
    float ldx, ldy, ldz;                     // baked eye-space headlamp direction
    const float*                 vpos;       // [verts*3] model-space positions
    const float*                 vnorm;      // [verts*3] model-space normals
    const float*                 vuv;        // [verts*2] texcoords
    const unsigned char*         vbone;      // [verts] bone index per vertex
    const unsigned short* const* idx;        // [mats] triangle indices per material
    const int*                   idxcount;   // [mats] index count per material
    const unsigned int*   const* tex;        // [mats] RGBA8888 texture per material (0 = flat)
    const int*                   texw;       // [mats]
    const int*                   texh;       // [mats]
    const float*          const* clip;       // [clips] flattened {px,py,pz,qw,qx,qy,qz}
    const int*                   clipframes; // [clips]
    const unsigned char*         cliploop;   // [clips]
} AfnRig;

// A static scene mesh (level chunk, prop). One draw per referencing instance.
typedef struct {
    int                   vertCount;
    int                   indexCount;   // triangle indices (16-bit)
    const AfnVertex*      verts;
    const unsigned short* indices;
    int                   textured;
    int                   texW, texH;
    const unsigned int*   texPixels;    // RGBA8888 linear
    int                   texHasAlpha;  // 1 = blend, 0 = opaque
    int                   cullMode;     // 0 back, 1 front, 2 none
    int                   lit;          // 1 = lit, 0 = unlit
    int                   visible;      // 0 = collision-only
} AfnMesh;

// A placed instance of a mesh in the world.
typedef struct {
    float x, y, z;
    float scale;
    float rotY, rotX, rotZ;   // degrees
    int   meshIdx;            // index into afn_meshes (-1 = none)
} AfnSpriteInst;

// ---- Generated data (psv_mapdata.h) -------------------------------------
extern const int            afn_mesh_count;
extern const AfnMesh        afn_meshes[];
extern const int            afn_sprite_count;
extern const AfnSpriteInst  afn_sprites[];

extern const float afn_cam_start_x, afn_cam_start_z, afn_cam_start_h;
extern const float afn_cam_start_angle;   // radians
extern const float afn_orbit_dist;
extern const float afn_draw_distance;     // 0 = unlimited
extern const float afn_walk_speed, afn_sprint_speed;
