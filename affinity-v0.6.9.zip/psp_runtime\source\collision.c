// Affinity PSP runtime — mesh collision (see collision.h).
// Faces are built once from the exported mesh geometry: each mesh-instance
// triangle is transformed to world space (same scale->Ry->Rx->Rz->translate as
// the renderer), classified floor/wall/ceiling by its normal, and bucketed into
// an XZ grid for cheap per-cell queries. Float port of nds_runtime/collision.c.
#include "collision.h"
#include "affinity_psp.h"
#include "psp_player.h"   // AFN_PLAYER_COL_* (custom collision box, if authored)
#include <math.h>
#include <stdlib.h>

#define COL_GN     16
#define COL_NCELL  (COL_GN * COL_GN)

typedef struct {
    float ax, ay, az, bx, by, bz, cx, cy, cz;
    float nx, ny, nz;   // full unit face normal
    int   flags;        // 1 = floor, 2 = ceiling, 4 = wall
} ColFace;

static ColFace* s_faces = 0;
static int      s_faceCount = 0;
static int*     s_cellStart = 0;
static int*     s_cellCount = 0;
static int*     s_cellFaces = 0;
static float    s_minX, s_minZ, s_cellSize;
static int      s_ready = 0;

// Per-face "seen this query" stamps so a face bucketed into several neighbouring
// cells is only processed once per wall query (else it would be pushed twice).
static unsigned* s_faceStamp = 0;
static unsigned  s_queryStamp = 0;

static int cell_x(float x) { int c = (int)((x - s_minX) / s_cellSize); return c < 0 ? 0 : (c >= COL_GN ? COL_GN-1 : c); }
static int cell_z(float z) { int c = (int)((z - s_minZ) / s_cellSize); return c < 0 ? 0 : (c >= COL_GN ? COL_GN-1 : c); }

void collide_build(void) {
    if (s_ready) return;
    s_ready = 1;
#if defined(AFN_SPRITE_COUNT) || 1
    // Count triangles across all mesh instances.
    int total = 0;
    for (int si = 0; si < afn_sprite_count; si++) {
        int mi = afn_sprites[si].meshIdx;
        if (mi < 0 || mi >= afn_mesh_count) continue;
        total += afn_meshes[mi].indexCount / 3;
    }
    if (total <= 0) return;
    s_faces = (ColFace*)malloc(sizeof(ColFace) * total);
    if (!s_faces) return;

    float mnx = 1e30f, mnz = 1e30f, mxx = -1e30f, mxz = -1e30f;

    for (int si = 0; si < afn_sprite_count; si++) {
        const AfnSpriteInst* sp = &afn_sprites[si];
        int mi = sp->meshIdx;
        if (mi < 0 || mi >= afn_mesh_count) continue;
        const AfnMesh* m = &afn_meshes[mi];
        const AfnVertex* V = m->verts;
        const unsigned short* I = m->indices;

        float ry = sp->rotY * (3.14159265f/180.0f);
        float rx = sp->rotX * (3.14159265f/180.0f);
        float rz = sp->rotZ * (3.14159265f/180.0f);
        float cY=cosf(ry), sY=sinf(ry), cX=cosf(rx), sX=sinf(rx), cZ=cosf(rz), sZ=sinf(rz);
        float scl = sp->scale;

        for (int t = 0; t + 3 <= m->indexCount; t += 3) {
            float wp[9];
            for (int k = 0; k < 3; k++) {
                const AfnVertex* vv = &V[I[t+k]];
                float lx = vv->x * scl, ly = vv->y * scl, lz = vv->z * scl;
                float ax =  lx*cY + lz*sY, az = -lx*sY + lz*cY, ay = ly;     // Ry
                float ay2 = ay*cX - az*sX, az2 = ay*sX + az*cX;              // Rx
                float ax2 = ax*cZ - ay2*sZ, ay3 = ax*sZ + ay2*cZ;           // Rz
                wp[k*3+0] = sp->x + ax2;
                wp[k*3+1] = sp->y + ay3;
                wp[k*3+2] = sp->z + az2;
            }
            // Normal.
            float e1x=wp[3]-wp[0], e1y=wp[4]-wp[1], e1z=wp[5]-wp[2];
            float e2x=wp[6]-wp[0], e2y=wp[7]-wp[1], e2z=wp[8]-wp[2];
            float nx=e1y*e2z-e1z*e2y, ny=e1z*e2x-e1x*e2z, nz=e1x*e2y-e1y*e2x;
            float len=sqrtf(nx*nx+ny*ny+nz*nz);
            if (len < 1e-6f) continue;
            nx/=len; ny/=len; nz/=len;
            ColFace* F = &s_faces[s_faceCount++];
            F->ax=wp[0];F->ay=wp[1];F->az=wp[2];
            F->bx=wp[3];F->by=wp[4];F->bz=wp[5];
            F->cx=wp[6];F->cy=wp[7];F->cz=wp[8];
            F->flags = (ny > 0.3f) ? 1 : (ny < -0.7f) ? 2 : 4;
            F->nx = nx; F->ny = ny; F->nz = nz;   // full unit normal
            for (int k=0;k<3;k++){ float X=wp[k*3], Z=wp[k*3+2];
                if(X<mnx)mnx=X; if(X>mxx)mxx=X; if(Z<mnz)mnz=Z; if(Z>mxz)mxz=Z; }
        }
    }
    if (s_faceCount <= 0) return;

    // Grid over the world XZ bounds.
    s_minX = mnx; s_minZ = mnz;
    float span = (mxx-mnx) > (mxz-mnz) ? (mxx-mnx) : (mxz-mnz);
    s_cellSize = span / COL_GN; if (s_cellSize < 1.0f) s_cellSize = 1.0f;

    s_cellStart = (int*)calloc(COL_NCELL, sizeof(int));
    s_cellCount = (int*)calloc(COL_NCELL, sizeof(int));
    s_faceStamp = (unsigned*)calloc(s_faceCount, sizeof(unsigned));
    if (!s_cellStart || !s_cellCount || !s_faceStamp) return;

    // Pass A: count (a face goes in every cell its XZ AABB overlaps).
    for (int i = 0; i < s_faceCount; i++) {
        const ColFace* F = &s_faces[i];
        float x0=F->ax,x1=F->bx,x2=F->cx, z0=F->az,z1=F->bz,z2=F->cz;
        float mnX=fminf(x0,fminf(x1,x2)), mxX=fmaxf(x0,fmaxf(x1,x2));
        float mnZ=fminf(z0,fminf(z1,z2)), mxZ=fmaxf(z0,fmaxf(z1,z2));
        for (int gz=cell_z(mnZ); gz<=cell_z(mxZ); gz++)
            for (int gx=cell_x(mnX); gx<=cell_x(mxX); gx++)
                s_cellCount[gz*COL_GN+gx]++;
    }
    int totalEntries = 0;
    for (int c = 0; c < COL_NCELL; c++) { s_cellStart[c]=totalEntries; totalEntries+=s_cellCount[c]; s_cellCount[c]=0; }
    s_cellFaces = (int*)malloc(sizeof(int) * (totalEntries > 0 ? totalEntries : 1));
    if (!s_cellFaces) return;
    // Pass B: fill.
    for (int i = 0; i < s_faceCount; i++) {
        const ColFace* F = &s_faces[i];
        float x0=F->ax,x1=F->bx,x2=F->cx, z0=F->az,z1=F->bz,z2=F->cz;
        float mnX=fminf(x0,fminf(x1,x2)), mxX=fmaxf(x0,fmaxf(x1,x2));
        float mnZ=fminf(z0,fminf(z1,z2)), mxZ=fmaxf(z0,fmaxf(z1,z2));
        for (int gz=cell_z(mnZ); gz<=cell_z(mxZ); gz++)
            for (int gx=cell_x(mnX); gx<=cell_x(mxX); gx++) {
                int c = gz*COL_GN+gx;
                s_cellFaces[s_cellStart[c] + s_cellCount[c]++] = i;
            }
    }
#endif
}

#define PLAYER_RADIUS 6.0f
#define PLAYER_HEIGHT 24.0f

// Player collision dimensions: use the authored custom box (psp_player.h, baked
// to world units at export) when present, else the default cylinder. COL_BOTTOM/
// COL_TOP are the box's vertical extent as offsets from the floor-snapped player
// Y; COL_RADIUS is the horizontal half-width.
#ifdef AFN_HAS_PLAYER_COL
#define COL_RADIUS AFN_PLAYER_COL_RADIUS
#define COL_BOTTOM AFN_PLAYER_COL_BOTTOM
#define COL_TOP    AFN_PLAYER_COL_TOP
#else
#define COL_RADIUS PLAYER_RADIUS
#define COL_BOTTOM 0.0f
#define COL_TOP    PLAYER_HEIGHT
#endif

// A wall whose top is within this far above the player's feet doesn't block —
// lets you walk off the edge of a ledge you're standing on (the floor you're
// snapped to can sit a hair below the wall's top vertex with float coords or an
// unwelded floor/wall seam, which would otherwise leave the side wall active and
// shove you back). Also acts as a gentle auto-step over tiny lips.
#define WALL_TOP_TOL  5.0f

int collide_floor(float x, float z, float py, float* outY, float* outN) {
    if (!s_cellFaces) return 0;
    int c = cell_z(z)*COL_GN + cell_x(x);
    int start = s_cellStart[c], count = s_cellCount[c];
    float bestY = 0; int found = 0; const ColFace* bestF = 0;
    for (int i = 0; i < count; i++) {
        const ColFace* F = &s_faces[s_cellFaces[start+i]];
        if (!(F->flags & 1)) continue;
        // Barycentric in XZ.
        float c0 = (F->bx-F->ax)*(z-F->az) - (F->bz-F->az)*(x-F->ax);
        float c1 = (F->cx-F->bx)*(z-F->bz) - (F->cz-F->bz)*(x-F->bx);
        float c2 = (F->ax-F->cx)*(z-F->cz) - (F->az-F->cz)*(x-F->cx);
        if (!((c0>=0&&c1>=0&&c2>=0)||(c0<=0&&c1<=0&&c2<=0))) continue;
        float cs = c0+c1+c2;
        float fy = (cs==0) ? (F->ay+F->by+F->cy)/3.0f
                           : (c1*F->ay + c2*F->by + c0*F->cy)/cs;
        if (fy > py + COL_TOP) continue;   // ignore floors above the head
        if (!found || fy > bestY) { bestY = fy; found = 1; bestF = F; }
    }
    *outY = bestY;
    if (outN) {
        if (bestF) { outN[0]=bestF->nx; outN[1]=bestF->ny; outN[2]=bestF->nz; }
        else { outN[0]=0; outN[1]=1; outN[2]=0; }
    }
    return found;
}

void collide_walls(float* x, float* z, float py) {
    if (!s_cellFaces || !s_faceStamp) return;
    float ppx = *x, ppz = *z;

    // Sweep every cell the player's collision radius overlaps, not just the cell
    // the player's centre is in. A wall sits up to PLAYER_RADIUS away, and with
    // the fine collision grid that wall often lives in a neighbouring cell — if
    // we only checked the centre cell we'd silently skip it and walk through the
    // wall. The radius is smaller than a cell so this is at most a 2x2 sweep.
    int gx0 = cell_x(ppx - COL_RADIUS), gx1 = cell_x(ppx + COL_RADIUS);
    int gz0 = cell_z(ppz - COL_RADIUS), gz1 = cell_z(ppz + COL_RADIUS);
    unsigned stamp = ++s_queryStamp;

    for (int gz = gz0; gz <= gz1; gz++)
    for (int gx = gx0; gx <= gx1; gx++) {
        int c = gz*COL_GN + gx;
        int start = s_cellStart[c], count = s_cellCount[c];
        for (int i = 0; i < count; i++) {
            int fi = s_cellFaces[start+i];
            if (s_faceStamp[fi] == stamp) continue;   // already handled this query
            s_faceStamp[fi] = stamp;
            const ColFace* F = &s_faces[fi];
            if (!(F->flags & 4)) continue;
            float fMinY = fminf(F->ay, fminf(F->by, F->cy));
            float fMaxY = fmaxf(F->ay, fmaxf(F->by, F->cy));
            if (py + COL_TOP < fMinY || py + COL_BOTTOM >= fMaxY - WALL_TOP_TOL) continue;
            if (F->nx*F->nx + F->nz*F->nz < 1e-8f) continue;   // purely vertical normal

            // Resolve the player as a CIRCLE vs the wall triangle's actual finite
            // footprint in XZ (its edges), not an infinite plane. Find the closest
            // point on any of the 3 edges and push radially away from it. Past the
            // wall's end the closest point is a corner vertex, so the push rotates
            // around the corner and the player slides off the edge — instead of
            // being shoved straight out by an over-extended plane (the old AABB-pad
            // method, which jittered at sharp edges).
            float vx[3] = { F->ax, F->bx, F->cx };
            float vz[3] = { F->az, F->bz, F->cz };
            float bestPx = ppx, bestPz = ppz, bestD2 = 1e30f;
            for (int e = 0; e < 3; e++) {
                float x0 = vx[e], z0 = vz[e];
                float sx = vx[(e+1)%3] - x0, sz = vz[(e+1)%3] - z0;
                float L2 = sx*sx + sz*sz;
                float t = (L2 > 1e-8f) ? ((ppx-x0)*sx + (ppz-z0)*sz) / L2 : 0.0f;
                if (t < 0.0f) t = 0.0f; else if (t > 1.0f) t = 1.0f;
                float Px = x0 + sx*t, Pz = z0 + sz*t;
                float dx = ppx - Px, dz = ppz - Pz, d2 = dx*dx + dz*dz;
                if (d2 < bestD2) { bestD2 = d2; bestPx = Px; bestPz = Pz; }
            }
            if (bestD2 >= COL_RADIUS*COL_RADIUS) continue;
            float d = sqrtf(bestD2);
            float push = COL_RADIUS - d;
            if (d > 1e-4f) {
                ppx += (ppx - bestPx) / d * push;
                ppz += (ppz - bestPz) / d * push;
            } else {
                // Player exactly on the wall line: shove out along the face normal.
                float xl = sqrtf(F->nx*F->nx + F->nz*F->nz);
                ppx += F->nx / xl * push;
                ppz += F->nz / xl * push;
            }
        }
    }
    *x = ppx; *z = ppz;
}
